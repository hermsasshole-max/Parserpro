import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import type { SavedReceipt } from '../types';
import { compareMonths, generateMonthReport } from './reportUtils';

export interface PDFExportOptions {
  monthA: string;
  monthB: string;
  receipts: SavedReceipt[];
}

/**
 * Robust cross-browser and mobile helper to download a Blob as a named file
 */
export function downloadBlobAsFile(blob: Blob, fileName: string): boolean {
  try {
    // 1. IE / legacy Edge
    if (typeof (navigator as any).msSaveBlob === 'function') {
      (navigator as any).msSaveBlob(blob, fileName);
      return true;
    }

    // 2. Standard Blob URL download
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = fileName;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    document.body.appendChild(a);
    
    // Programmatic click
    a.click();

    // Clean up DOM and revoke Blob URL after delay
    setTimeout(() => {
      try {
        if (document.body.contains(a)) {
          document.body.removeChild(a);
        }
        URL.revokeObjectURL(url);
      } catch (_) {}
    }, 15000);

    return true;
  } catch (err) {
    console.error('downloadBlobAsFile failed:', err);
    return false;
  }
}

/**
 * Builds a high-resolution, multi-page vector PDF report comparing Month A vs Month B
 */
export function buildComparisonPDFDoc(monthA: string, monthB: string, receipts: SavedReceipt[]): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const comparison = compareMonths(monthA, monthB, receipts);
  const isNetSaving = comparison.totalDiff < 0;
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  // Color Palette
  const primaryNavy = [15, 23, 42]; // #0f172a
  const emeraldGreen = [5, 150, 105]; // #059669
  const roseRed = [225, 29, 72]; // #e11d48
  const slateMuted = [100, 116, 139]; // #64748b
  const slateLight = [248, 250, 252]; // #f8fafc

  let y = 14;

  // Header Banner
  doc.setFillColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.rect(14, y, pageWidth - 28, 22, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text('HOUSEHOLD EXPENDITURE & GROCERY REPORT', 18, y + 8);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(203, 213, 225);
  doc.text(`Comparative Analysis: ${monthA} vs ${monthB}  •  Currency: ZAR (R)`, 18, y + 16);

  // Date on the right of banner
  const genDate = new Date().toLocaleDateString('en-ZA');
  doc.setFontSize(8);
  doc.text(`Generated: ${genDate}`, pageWidth - 18, y + 8, { align: 'right' });
  doc.text('Confidential Personal Ledger', pageWidth - 18, y + 16, { align: 'right' });

  y += 28;

  // Executive Summary 3-Box Grid
  const boxWidth = (pageWidth - 28 - 8) / 3;
  const boxHeight = 22;

  // Box 1: Month A Spend
  doc.setFillColor(slateLight[0], slateLight[1], slateLight[2]);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, y, boxWidth, boxHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(slateMuted[0], slateMuted[1], slateMuted[2]);
  doc.text(`${monthA} TOTAL SPEND`, 18, y + 6);
  doc.setFontSize(12);
  doc.setTextColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.text(`R ${comparison.totalA.toFixed(2)}`, 18, y + 15);

  // Box 2: Month B Spend
  const box2X = 14 + boxWidth + 4;
  doc.setFillColor(slateLight[0], slateLight[1], slateLight[2]);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(box2X, y, boxWidth, boxHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(slateMuted[0], slateMuted[1], slateMuted[2]);
  doc.text(`${monthB} TOTAL SPEND`, box2X + 4, y + 6);
  doc.setFontSize(12);
  doc.setTextColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.text(`R ${comparison.totalB.toFixed(2)}`, box2X + 4, y + 15);

  // Box 3: Variance
  const box3X = box2X + boxWidth + 4;
  if (isNetSaving) {
    doc.setFillColor(236, 253, 245);
    doc.setDrawColor(167, 243, 208);
  } else {
    doc.setFillColor(255, 241, 242);
    doc.setDrawColor(254, 205, 211);
  }
  doc.roundedRect(box3X, y, boxWidth, boxHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(
    isNetSaving ? emeraldGreen[0] : roseRed[0],
    isNetSaving ? emeraldGreen[1] : roseRed[1],
    isNetSaving ? emeraldGreen[2] : roseRed[2]
  );
  doc.text(`NET VARIANCE (${isNetSaving ? 'SAVED' : 'INCREASED'})`, box3X + 4, y + 6);
  doc.setFontSize(11);
  const diffSign = isNetSaving ? '- R ' : '+ R ';
  doc.text(`${diffSign}${Math.abs(comparison.totalDiff).toFixed(2)}`, box3X + 4, y + 14);

  doc.setFontSize(7);
  doc.text(`${isNetSaving ? 'Saved ' : 'Up '}${Math.abs(comparison.totalPercentChange)}% vs ${monthB}`, box3X + 4, y + 19);

  y += boxHeight + 8;

  // Category Breakdown Section
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.text('CATEGORY EXPENDITURE BREAKDOWN', 14, y);
  y += 3;

  const categoryRows = comparison.categoryComparison.map(cat => [
    cat.category,
    `R ${cat.monthA.toFixed(2)}`,
    `R ${cat.monthB.toFixed(2)}`,
    cat.diff < 0
      ? `- R ${Math.abs(cat.diff).toFixed(2)} (Saved)`
      : cat.diff > 0
      ? `+ R ${cat.diff.toFixed(2)}`
      : 'R 0.00',
  ]);

  autoTable(doc, {
    startY: y,
    head: [['Category', `${monthA} Spend`, `${monthB} Spend`, 'Variance (ZAR)']],
    body: categoryRows,
    theme: 'grid',
    styles: {
      fontSize: 8,
      cellPadding: 2.2,
      font: 'helvetica',
      textColor: [30, 41, 59],
    },
    headStyles: {
      fillColor: [30, 41, 59],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      halign: 'left',
    },
    columnStyles: {
      0: { cellWidth: 'auto', fontStyle: 'bold' },
      1: { cellWidth: 35, halign: 'right' },
      2: { cellWidth: 35, halign: 'right' },
      3: { cellWidth: 38, halign: 'right' },
    },
    margin: { left: 14, right: 14 },
  });

  const lastTable = (doc as any).lastAutoTable;
  y = (lastTable ? lastTable.finalY : y) + 8;

  // Check if we need a new page for the items table header
  if (y > pageHeight - 45) {
    doc.addPage();
    y = 16;
  }

  // Alphabetical Item Table
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.text(`ITEM-BY-ITEM CALCULATED LEDGER (A-Z)  •  ${comparison.items.length} Unique Items`, 14, y);
  y += 3;

  const itemRows = comparison.items.length > 0 
    ? comparison.items.map(item => {
        const statusText = 
          item.status === 'saved_more' ? 'Saved More' :
          item.status === 'not_purchased' ? 'Not Bought' :
          item.status === 'spent_more' ? 'Spent More' :
          item.status === 'new_item' ? 'New Item' : 'Equal';

        const diffText = item.amount_diff < 0 
          ? `- R ${Math.abs(item.amount_diff).toFixed(2)}`
          : item.amount_diff > 0
          ? `+ R ${item.amount_diff.toFixed(2)}`
          : 'R 0.00';

        return [
          item.name,
          item.category,
          `${item.monthA_quantity}`,
          `R ${item.monthA_total.toFixed(2)}`,
          `${item.monthB_quantity}`,
          `R ${item.monthB_total.toFixed(2)}`,
          diffText,
          statusText
        ];
      })
    : [['No recorded items for these months', '', '', 'R 0.00', '', 'R 0.00', 'R 0.00', '-']];

  autoTable(doc, {
    startY: y,
    head: [[
      'Item Description (A-Z)',
      'Category',
      `${monthA} Qty`,
      `${monthA} Total`,
      `${monthB} Qty`,
      `${monthB} Total`,
      'Variance',
      'Status'
    ]],
    body: itemRows,
    foot: [[
      'GRAND TOTALS',
      '',
      '',
      `R ${comparison.totalA.toFixed(2)}`,
      '',
      `R ${comparison.totalB.toFixed(2)}`,
      `${isNetSaving ? '- R ' : '+ R '}${Math.abs(comparison.totalDiff).toFixed(2)}`,
      isNetSaving ? 'Saved' : 'Increased'
    ]],
    theme: 'striped',
    styles: {
      fontSize: 7.5,
      cellPadding: 1.8,
      font: 'helvetica',
      textColor: [15, 23, 42],
    },
    headStyles: {
      fillColor: [15, 23, 42],
      textColor: [255, 255, 255],
      fontStyle: 'bold',
      fontSize: 7.5,
    },
    footStyles: {
      fillColor: [241, 245, 249],
      textColor: [15, 23, 42],
      fontStyle: 'bold',
      fontSize: 8,
    },
    columnStyles: {
      0: { cellWidth: 'auto', fontStyle: 'bold' },
      1: { cellWidth: 26 },
      2: { cellWidth: 12, halign: 'center' },
      3: { cellWidth: 20, halign: 'right' },
      4: { cellWidth: 12, halign: 'center' },
      5: { cellWidth: 20, halign: 'right' },
      6: { cellWidth: 24, halign: 'right' },
      7: { cellWidth: 20, halign: 'center' },
    },
    margin: { left: 14, right: 14, bottom: 16 },
  });

  // Second pass: Add accurate "Page X of Y" footer to all pages
  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(148, 163, 184);
    doc.text(
      `ParserPro Household Ledger  •  Page ${i} of ${totalPages}`,
      14,
      pageHeight - 8
    );
    doc.text(
      'Confidential Personal Finance Document',
      pageWidth - 14,
      pageHeight - 8,
      { align: 'right' }
    );
  }

  return doc;
}

/**
 * Builds a single-month PDF report with receipts list and itemized ledger
 */
export function buildSingleMonthPDFDoc(monthYear: string, receipts: SavedReceipt[]): jsPDF {
  const doc = new jsPDF({
    orientation: 'portrait',
    unit: 'mm',
    format: 'a4',
  });

  const monthReceipts = receipts.filter(r => r.month_year === monthYear);
  const report = generateMonthReport(monthYear, receipts);
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();

  const primaryNavy = [15, 23, 42];
  const slateLight = [248, 250, 252];
  const slateMuted = [100, 116, 139];

  let y = 14;

  // Header Banner
  doc.setFillColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.rect(14, y, pageWidth - 28, 22, 'F');

  doc.setTextColor(255, 255, 255);
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(13);
  doc.text('MONTHLY HOUSEHOLD EXPENDITURE LEDGER', 18, y + 8);

  doc.setFont('helvetica', 'normal');
  doc.setFontSize(8.5);
  doc.setTextColor(203, 213, 225);
  doc.text(`Filing Month: ${monthYear}  •  Currency: ZAR (R)`, 18, y + 16);

  const genDate = new Date().toLocaleDateString('en-ZA');
  doc.setFontSize(8);
  doc.text(`Generated: ${genDate}`, pageWidth - 18, y + 8, { align: 'right' });
  doc.text('Confidential Personal Ledger', pageWidth - 18, y + 16, { align: 'right' });

  y += 28;

  // Summary 3-Box Grid
  const boxWidth = (pageWidth - 28 - 8) / 3;
  const boxHeight = 20;

  // Box 1: Total Spend
  doc.setFillColor(slateLight[0], slateLight[1], slateLight[2]);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, y, boxWidth, boxHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(slateMuted[0], slateMuted[1], slateMuted[2]);
  doc.text('TOTAL MONTH SPEND', 18, y + 6);
  doc.setFontSize(12);
  doc.setTextColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.text(`R ${report.total_spend.toFixed(2)}`, 18, y + 14);

  // Box 2: Total Receipts
  const box2X = 14 + boxWidth + 4;
  doc.setFillColor(slateLight[0], slateLight[1], slateLight[2]);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(box2X, y, boxWidth, boxHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(slateMuted[0], slateMuted[1], slateMuted[2]);
  doc.text('TOTAL RECEIPTS FILED', box2X + 4, y + 6);
  doc.setFontSize(12);
  doc.setTextColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.text(`${report.receipt_count} Receipts`, box2X + 4, y + 14);

  // Box 3: Total Unique Items
  const box3X = box2X + boxWidth + 4;
  doc.setFillColor(slateLight[0], slateLight[1], slateLight[2]);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(box3X, y, boxWidth, boxHeight, 2, 2, 'FD');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(7.5);
  doc.setTextColor(slateMuted[0], slateMuted[1], slateMuted[2]);
  doc.text('TOTAL UNIQUE ITEMS', box3X + 4, y + 6);
  doc.setFontSize(12);
  doc.setTextColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.text(`${report.item_count} Items`, box3X + 4, y + 14);

  y += boxHeight + 8;

  // Category Breakdown
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.text('CATEGORY EXPENDITURE BREAKDOWN', 14, y);
  y += 3;

  const catRows = Object.entries(report.category_totals).map(([cat, amount]) => {
    const pct = report.total_spend > 0 ? ((amount / report.total_spend) * 100).toFixed(1) : '0.0';
    return [cat, `R ${amount.toFixed(2)}`, `${pct}%`];
  });

  autoTable(doc, {
    startY: y,
    head: [['Category', 'Total Spend (ZAR)', '% of Monthly Spend']],
    body: catRows,
    theme: 'grid',
    styles: { fontSize: 8, cellPadding: 2, font: 'helvetica' },
    headStyles: { fillColor: [30, 41, 59], textColor: [255, 255, 255], fontStyle: 'bold' },
    columnStyles: {
      0: { cellWidth: 'auto', fontStyle: 'bold' },
      1: { cellWidth: 45, halign: 'right' },
      2: { cellWidth: 45, halign: 'right' },
    },
    margin: { left: 14, right: 14 },
  });

  let nextY = ((doc as any).lastAutoTable?.finalY || y) + 8;

  // Receipts Table
  if (nextY > pageHeight - 40) {
    doc.addPage();
    nextY = 16;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.text(`RECORDED RECEIPTS (${monthReceipts.length})`, 14, nextY);
  nextY += 3;

  const receiptRows = monthReceipts.map(r => [
    r.invoice_date,
    r.vendor_name || 'Store / Merchant',
    r.category,
    r.tax ? `VAT: R ${Number(r.tax).toFixed(2)}` : (r.notes || 'Paid'),
    `R ${(Number(r.total_amount) || 0).toFixed(2)}`
  ]);

  autoTable(doc, {
    startY: nextY,
    head: [['Date', 'Store / Merchant', 'Category', 'Tax / Notes', 'Amount (ZAR)']],
    body: receiptRows.length > 0 ? receiptRows : [['No receipts filed for this month', '', '', '', 'R 0.00']],
    theme: 'striped',
    styles: { fontSize: 7.5, cellPadding: 1.8, font: 'helvetica' },
    headStyles: { fillColor: [15, 23, 42], textColor: [255, 255, 255], fontStyle: 'bold' },
    columnStyles: {
      0: { cellWidth: 26 },
      1: { cellWidth: 'auto', fontStyle: 'bold' },
      2: { cellWidth: 38 },
      3: { cellWidth: 30 },
      4: { cellWidth: 32, halign: 'right', fontStyle: 'bold' },
    },
    margin: { left: 14, right: 14 },
  });

  nextY = ((doc as any).lastAutoTable?.finalY || nextY) + 8;

  // Itemized Ledger (A-Z)
  if (nextY > pageHeight - 40) {
    doc.addPage();
    nextY = 16;
  }

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9.5);
  doc.setTextColor(primaryNavy[0], primaryNavy[1], primaryNavy[2]);
  doc.text(`ITEMIZED GROCERY & GOODS LEDGER (A-Z) • ${report.items_alphabetical.length} Unique Items`, 14, nextY);
  nextY += 3;

  const itemRows = report.items_alphabetical.map(i => [
    i.name,
    i.categories.join(', ') || 'Groceries',
    `${i.total_quantity}`,
    `R ${i.average_unit_price.toFixed(2)}`,
    `R ${i.total_amount.toFixed(2)}`
  ]);

  autoTable(doc, {
    startY: nextY,
    head: [['Item Description (A-Z)', 'Category', 'Total Qty', 'Avg Unit Price', 'Total Spend (ZAR)']],
    body: itemRows.length > 0 ? itemRows : [['No line items recorded', '', '', '', 'R 0.00']],
    foot: [['TOTAL', '', '', '', `R ${report.total_spend.toFixed(2)}`]],
    theme: 'striped',
    styles: { fontSize: 7.5, cellPadding: 1.8, font: 'helvetica' },
    headStyles: { fillColor: [15, 23, 42], textColor: [255, 255, 255], fontStyle: 'bold' },
    footStyles: { fillColor: [241, 245, 249], textColor: [15, 23, 42], fontStyle: 'bold' },
    columnStyles: {
      0: { cellWidth: 'auto', fontStyle: 'bold' },
      1: { cellWidth: 42 },
      2: { cellWidth: 20, halign: 'center' },
      3: { cellWidth: 25, halign: 'right' },
      4: { cellWidth: 25, halign: 'right' },
    },
    margin: { left: 14, right: 14, bottom: 16 },
  });

  const totalPages = doc.getNumberOfPages();
  for (let i = 1; i <= totalPages; i++) {
    doc.setPage(i);
    doc.setFontSize(7.5);
    doc.setFont('helvetica', 'normal');
    doc.setTextColor(148, 163, 184);
    doc.text(
      `ParserPro Monthly Ledger  •  ${monthYear}  •  Page ${i} of ${totalPages}`,
      14,
      pageHeight - 8
    );
    doc.text(
      'Confidential Personal Finance Document',
      pageWidth - 14,
      pageHeight - 8,
      { align: 'right' }
    );
  }

  return doc;
}

/**
 * Downloads the comparison PDF directly onto the device storage
 */
export async function downloadComparisonPDF(monthA: string, monthB: string, receipts: SavedReceipt[]): Promise<boolean> {
  try {
    const doc = buildComparisonPDFDoc(monthA, monthB, receipts);
    const fileName = `Expenditure_Report_${monthA}_vs_${monthB}.pdf`;
    const blob = doc.output('blob');
    return downloadBlobAsFile(blob, fileName);
  } catch (error) {
    console.error('Error generating and downloading comparison PDF:', error);
    return false;
  }
}

/**
 * Downloads a single month's detailed PDF report
 */
export async function downloadSingleMonthPDF(monthYear: string, receipts: SavedReceipt[]): Promise<boolean> {
  try {
    const doc = buildSingleMonthPDFDoc(monthYear, receipts);
    const fileName = `Monthly_Ledger_${monthYear}.pdf`;
    const blob = doc.output('blob');
    return downloadBlobAsFile(blob, fileName);
  } catch (error) {
    console.error('Error generating and downloading single month PDF:', error);
    return false;
  }
}

/**
 * Opens the vector PDF in a new tab/window for instant viewing and printing
 */
export function openPdfInNewTab(monthA: string, monthB: string, receipts: SavedReceipt[]): boolean {
  try {
    const doc = buildComparisonPDFDoc(monthA, monthB, receipts);
    const blob = doc.output('blob');
    const blobUrl = URL.createObjectURL(blob);
    const newWindow = window.open(blobUrl, '_blank');
    if (!newWindow) {
      // If popup blocker intervened, fall back to direct file download
      return downloadBlobAsFile(blob, `Expenditure_Report_${monthA}_vs_${monthB}.pdf`);
    }
    setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
    return true;
  } catch (err) {
    console.error('openPdfInNewTab failed:', err);
    return false;
  }
}

/**
 * Shares or saves PDF via Web Share API (Android Native Share sheet)
 */
export async function shareOrSavePDF(monthA: string, monthB: string, receipts: SavedReceipt[]): Promise<boolean> {
  const fileName = `Expenditure_Report_${monthA}_vs_${monthB}.pdf`;
  try {
    const doc = buildComparisonPDFDoc(monthA, monthB, receipts);
    const pdfBlob = doc.output('blob');
    const file = new File([pdfBlob], fileName, { type: 'application/pdf' });

    // Check if navigator.share supports file sharing
    if (typeof navigator !== 'undefined' && navigator.canShare && navigator.canShare({ files: [file] })) {
      await navigator.share({
        title: `Expenditure Report: ${monthA} vs ${monthB}`,
        text: `Comparative household expenditure report for ${monthA} and ${monthB}.`,
        files: [file]
      });
      return true;
    } else {
      // Direct file download fallback
      return downloadBlobAsFile(pdfBlob, fileName);
    }
  } catch (error) {
    if ((error as any)?.name === 'AbortError') {
      // User cancelled share dialog
      return true;
    }
    console.warn('Share failed, attempting direct download:', error);
    try {
      const doc = buildComparisonPDFDoc(monthA, monthB, receipts);
      const pdfBlob = doc.output('blob');
      return downloadBlobAsFile(pdfBlob, fileName);
    } catch (e) {
      console.error('Direct download fallback failed:', e);
      return false;
    }
  }
}

/**
 * Robust print handler that isolates the printable document and triggers print
 * Works across desktop, Android Chrome, and mobile browsers.
 */
export function printReportSafely(monthA: string, monthB: string, receipts: SavedReceipt[]): void {
  // 1. Tag the document body to signal print styles
  document.body.classList.add('printing-report');

  const cleanup = () => {
    document.body.classList.remove('printing-report');
    window.removeEventListener('afterprint', cleanup);
  };
  window.addEventListener('afterprint', cleanup);

  try {
    if (typeof window.print === 'function') {
      window.print();
      // Safe fallback timer to clean up classes if afterprint does not fire
      setTimeout(cleanup, 2500);
      return;
    }
  } catch (err) {
    console.warn('window.print threw, falling back to PDF download:', err);
    cleanup();
  }

  // Fallback: If printing is unavailable or restricted
  downloadComparisonPDF(monthA, monthB, receipts);
}
