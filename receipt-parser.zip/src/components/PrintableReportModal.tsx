import React, { useState } from 'react';
import { 
  Printer, 
  Download, 
  X, 
  FileText, 
  Check, 
  TrendingDown, 
  TrendingUp, 
  Share2, 
  FileDown, 
  Loader2,
  ExternalLink,
  Calendar,
  AlertCircle
} from 'lucide-react';
import type { SavedReceipt } from '../types';
import { 
  compareMonths, 
  exportComparisonToCSV, 
  generateMonthlyMarkdownReport, 
  exportMarkdownReport,
  generateMonthReport
} from '../utils/reportUtils';
import { 
  downloadComparisonPDF, 
  downloadSingleMonthPDF,
  shareOrSavePDF, 
  printReportSafely,
  openPdfInNewTab
} from '../utils/pdfGenerator';

interface PrintableReportModalProps {
  receipts: SavedReceipt[];
  monthA: string;
  monthB: string;
  onClose: () => void;
}

export const PrintableReportModal: React.FC<PrintableReportModalProps> = ({
  receipts,
  monthA: initialMonthA,
  monthB: initialMonthB,
  onClose
}) => {
  const [monthA, setMonthA] = useState(initialMonthA);
  const [monthB, setMonthB] = useState(initialMonthB);
  const [viewMode, setViewMode] = useState<'comparison' | 'single'>('comparison');
  
  const [copiedMd, setCopiedMd] = useState(false);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isOpeningPdf, setIsOpeningPdf] = useState(false);
  const [pdfSuccess, setPdfSuccess] = useState<string | null>(null);
  const [pdfError, setPdfError] = useState<string | null>(null);

  // Available unique months from receipts
  const availableMonths = React.useMemo(() => {
    const months = Array.from(new Set(receipts.map(r => r.month_year))).filter(Boolean);
    months.sort().reverse();
    return months.length > 0 ? months : [monthA, monthB].filter(Boolean);
  }, [receipts, monthA, monthB]);

  const comparison = compareMonths(monthA, monthB, receipts);
  const isNetSaving = comparison.totalDiff < 0;

  const singleMonthReport = generateMonthReport(monthA, receipts);
  const singleMonthReceipts = receipts.filter(r => r.month_year === monthA);

  const showToast = (msg: string, isError = false) => {
    if (isError) {
      setPdfError(msg);
      setPdfSuccess(null);
      setTimeout(() => setPdfError(null), 5000);
    } else {
      setPdfSuccess(msg);
      setPdfError(null);
      setTimeout(() => setPdfSuccess(null), 4000);
    }
  };

  // 1. Download PDF (Vector .pdf file saved to device)
  const handleDownloadPDF = async () => {
    setIsGeneratingPdf(true);
    setPdfSuccess(null);
    setPdfError(null);
    try {
      let ok = false;
      if (viewMode === 'comparison') {
        ok = await downloadComparisonPDF(monthA, monthB, receipts);
      } else {
        ok = await downloadSingleMonthPDF(monthA, receipts);
      }

      if (ok) {
        showToast(`PDF report (${viewMode === 'comparison' ? `${monthA}_vs_${monthB}` : monthA}) downloaded to your device!`);
      } else {
        showToast('Could not complete PDF download. Please try Print to PDF.', true);
      }
    } catch (e: any) {
      console.error('PDF download error:', e);
      showToast(e?.message || 'Failed to generate PDF.', true);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  // 2. Print to PDF (Open vector PDF in new tab for direct PDF viewing and browser printing)
  const handlePrintToPDF = async () => {
    setIsOpeningPdf(true);
    setPdfSuccess(null);
    setPdfError(null);
    try {
      const ok = openPdfInNewTab(monthA, monthB, receipts);
      if (ok) {
        showToast('Opened vector PDF preview in a new window/tab! Use the browser print button to Print to PDF.');
      } else {
        // Fallback: trigger download
        await downloadComparisonPDF(monthA, monthB, receipts);
        showToast('PDF downloaded to your device Downloads folder.');
      }
    } catch (e: any) {
      console.error('Print to PDF error:', e);
      showToast('Error opening PDF viewer, falling back to download.', true);
      downloadComparisonPDF(monthA, monthB, receipts);
    } finally {
      setIsOpeningPdf(false);
    }
  };

  // 3. Print Report (Direct system print / Android print spooler with exact styles)
  const handlePrint = () => {
    showToast('Opening print dialog...');
    printReportSafely(monthA, monthB, receipts);
  };

  // 4. Share or Save via Mobile Share Sheet
  const handleShareOrSavePDF = async () => {
    setIsGeneratingPdf(true);
    try {
      const ok = await shareOrSavePDF(monthA, monthB, receipts);
      if (ok) {
        showToast('PDF ready! Opened Android Share or saved to Downloads.');
      }
    } catch (e) {
      console.error('PDF share error:', e);
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleExportCSV = () => {
    exportComparisonToCSV(monthA, monthB, comparison.items);
    showToast('Exported comparison to CSV spreadsheet.');
  };

  const handleExportMarkdown = () => {
    const mdA = generateMonthlyMarkdownReport(monthA, receipts);
    const mdB = generateMonthlyMarkdownReport(monthB, receipts);
    const combinedMd = `${mdA}\n\n${mdB}`;
    exportMarkdownReport(combinedMd, `Expenditure_Report_${monthA}_${monthB}.md`);
    showToast('Exported formatted Markdown file.');
  };

  const handleCopyMarkdown = () => {
    const mdA = generateMonthlyMarkdownReport(monthA, receipts);
    const mdB = generateMonthlyMarkdownReport(monthB, receipts);
    const combinedMd = `${mdA}\n\n${mdB}`;
    navigator.clipboard.writeText(combinedMd).then(() => {
      setCopiedMd(true);
      showToast('Report copied to clipboard.');
      setTimeout(() => setCopiedMd(false), 2500);
    });
  };

  return (
    <div 
      id="printable-modal-backdrop"
      className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex flex-col items-center justify-start overflow-y-auto p-2 sm:p-6"
    >
      {/* Top Action Bar (hidden on print) */}
      <div className="w-full max-w-4xl bg-slate-900 text-white p-3 sm:p-4 rounded-2xl mb-4 flex flex-col gap-3 shadow-xl no-print">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 flex items-center justify-center shrink-0">
              <Printer className="w-4 h-4 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold">Expenditure & Ledger Report</h3>
                <span className="hidden sm:inline-block px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 text-[10px] font-bold rounded border border-emerald-400/30">
                  Vector PDF + Print
                </span>
              </div>
              <p className="text-[11px] text-slate-400">
                Download a clean vector PDF, print directly to printer, or save as PDF.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
            {/* Primary Download PDF Button */}
            <button
              onClick={handleDownloadPDF}
              disabled={isGeneratingPdf}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
              title="Generate and download vector PDF directly to your device storage"
            >
              {isGeneratingPdf ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <FileDown className="w-3.5 h-3.5" />
              )}
              <span>{isGeneratingPdf ? 'Generating...' : 'Download PDF'}</span>
            </button>

            {/* Print to PDF (Open in Viewer) Button */}
            <button
              onClick={handlePrintToPDF}
              disabled={isOpeningPdf}
              className="px-3 py-1.5 bg-blue-600 hover:bg-blue-500 active:bg-blue-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors shadow-sm cursor-pointer"
              title="Open vector PDF preview in a new window/tab to print to PDF"
            >
              {isOpeningPdf ? (
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
              ) : (
                <ExternalLink className="w-3.5 h-3.5" />
              )}
              <span>Print to PDF</span>
            </button>

            {/* Native Browser / Android Print Button */}
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-slate-200 text-xs font-bold rounded-xl flex items-center gap-1.5 transition-colors border border-slate-700 cursor-pointer"
              title="Open browser print dialog (Print or Save as PDF)"
            >
              <Printer className="w-3.5 h-3.5 text-slate-300" />
              <span>Print</span>
            </button>

            {/* Mobile / Android Share Sheet */}
            <button
              onClick={handleShareOrSavePDF}
              disabled={isGeneratingPdf}
              className="hidden sm:flex px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-emerald-300 text-xs font-bold rounded-xl items-center gap-1.5 transition-colors border border-emerald-500/30 cursor-pointer"
              title="Save to Android Files, Google Drive, or share via WhatsApp"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share</span>
            </button>

            {/* CSV Export */}
            <button
              onClick={handleExportCSV}
              className="hidden md:flex px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl items-center gap-1.5 transition-colors border border-slate-700 cursor-pointer"
              title="Export as CSV spreadsheet"
            >
              <Download className="w-3.5 h-3.5" />
              <span>CSV</span>
            </button>

            {/* Markdown Export */}
            <button
              onClick={handleExportMarkdown}
              className="hidden lg:flex px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl items-center gap-1.5 transition-colors border border-slate-700 cursor-pointer"
              title="Download formatted Markdown (.md) file"
            >
              <Download className="w-3.5 h-3.5" />
              <span>.MD</span>
            </button>

            {/* Copy Markdown */}
            <button
              onClick={handleCopyMarkdown}
              className="hidden lg:flex px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl items-center gap-1.5 transition-colors border border-slate-700 cursor-pointer"
              title="Copy Markdown report to clipboard"
            >
              {copiedMd ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <FileText className="w-3.5 h-3.5" />}
              <span>{copiedMd ? 'Copied' : 'Copy'}</span>
            </button>

            {/* Close Button */}
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded-xl transition-colors ml-1 cursor-pointer"
              title="Close report preview"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* View Toggle and Month Selectors */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-800 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-slate-400 font-medium">Report Mode:</span>
            <div className="inline-flex bg-slate-800 p-0.5 rounded-lg border border-slate-700">
              <button
                onClick={() => setViewMode('comparison')}
                className={`px-2.5 py-1 rounded-md text-xs font-bold transition-colors cursor-pointer ${
                  viewMode === 'comparison' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Comparison ({monthA} vs {monthB})
              </button>
              <button
                onClick={() => setViewMode('single')}
                className={`px-2.5 py-1 rounded-md text-xs font-bold transition-colors cursor-pointer ${
                  viewMode === 'single' ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Single Month ({monthA})
              </button>
            </div>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <div className="flex items-center gap-1">
              <Calendar className="w-3.5 h-3.5 text-slate-400" />
              <span className="text-slate-400">Month A:</span>
              <select
                value={monthA}
                onChange={(e) => setMonthA(e.target.value)}
                className="bg-slate-800 text-slate-100 text-xs border border-slate-700 rounded-lg px-2 py-1 focus:outline-none focus:border-emerald-500"
              >
                {availableMonths.map((m) => (
                  <option key={m} value={m}>{m}</option>
                ))}
              </select>
            </div>

            {viewMode === 'comparison' && (
              <div className="flex items-center gap-1">
                <span className="text-slate-400">vs Month B:</span>
                <select
                  value={monthB}
                  onChange={(e) => setMonthB(e.target.value)}
                  className="bg-slate-800 text-slate-100 text-xs border border-slate-700 rounded-lg px-2 py-1 focus:outline-none focus:border-emerald-500"
                >
                  {availableMonths.map((m) => (
                    <option key={m} value={m}>{m}</option>
                  ))}
                </select>
              </div>
            )}
          </div>
        </div>

        {/* Feedback Messages */}
        {pdfSuccess && (
          <div className="bg-emerald-950/80 border border-emerald-500/40 text-emerald-200 px-3 py-2 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{pdfSuccess}</span>
          </div>
        )}
        {pdfError && (
          <div className="bg-rose-950/80 border border-rose-500/40 text-rose-200 px-3 py-2 rounded-xl text-xs flex items-center gap-2 animate-in fade-in">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0" />
            <span>{pdfError}</span>
          </div>
        )}
      </div>

      {/* Printable Paper Document Container */}
      <div
        id="printable-report-area"
        className="w-full max-w-4xl bg-white text-slate-900 p-8 sm:p-12 rounded-2xl shadow-2xl border border-slate-200 print:shadow-none print:border-none print:p-0 print:m-0"
      >
        {viewMode === 'comparison' ? (
          <>
            {/* Document Header */}
            <div className="border-b-2 border-slate-900 pb-6 mb-6 flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-2xl font-black tracking-tight text-slate-900">
                    HOUSEHOLD EXPENDITURE & GROCERY REPORT
                  </span>
                </div>
                <p className="text-xs text-slate-500 font-medium">
                  Comparative Analysis: <strong className="text-slate-800">{monthA}</strong> vs <strong className="text-slate-800">{monthB}</strong>
                </p>
              </div>

              <div className="text-right">
                <div className="text-xs font-bold text-slate-800 uppercase">Generated On</div>
                <div className="text-xs text-slate-500">{new Date().toLocaleDateString('en-ZA')}</div>
                <div className="text-[10px] text-emerald-700 font-bold mt-1">Currency: ZAR (R)</div>
              </div>
            </div>

            {/* Executive Summary Cards */}
            <div className="grid grid-cols-3 gap-4 mb-6 print-page-break">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <div className="text-[10px] uppercase font-bold text-slate-400">
                  {monthA} Total Spend
                </div>
                <div className="text-xl font-black text-slate-900 mt-0.5">
                  R {comparison.totalA.toFixed(2)}
                </div>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <div className="text-[10px] uppercase font-bold text-slate-400">
                  {monthB} Total Spend
                </div>
                <div className="text-xl font-black text-slate-900 mt-0.5">
                  R {comparison.totalB.toFixed(2)}
                </div>
              </div>

              <div className={`p-4 rounded-xl border ${
                isNetSaving ? 'bg-emerald-50 border-emerald-200 text-emerald-950' : 'bg-rose-50 border-rose-200 text-rose-950'
              }`}>
                <div className="text-[10px] uppercase font-bold opacity-70">
                  Net Variance ({monthA} vs {monthB})
                </div>
                <div className="text-xl font-black mt-0.5 flex items-center gap-1">
                  {isNetSaving ? (
                    <>
                      <TrendingDown className="w-5 h-5 text-emerald-600" />
                      <span>- R {Math.abs(comparison.totalDiff).toFixed(2)}</span>
                    </>
                  ) : (
                    <>
                      <TrendingUp className="w-5 h-5 text-rose-600" />
                      <span>+ R {comparison.totalDiff.toFixed(2)}</span>
                    </>
                  )}
                </div>
                <div className="text-[10px] font-bold mt-0.5">
                  {isNetSaving ? `Net Savings: ${Math.abs(comparison.totalPercentChange)}%` : `Net Increase: +${comparison.totalPercentChange}%`}
                </div>
              </div>
            </div>

            {/* Category Breakdown */}
            <div className="mb-8 print-page-break">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-3">
                Category Breakdown
              </h4>
              <table className="w-full text-left text-xs border border-slate-200">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2 px-3">Category</th>
                    <th className="py-2 px-3 text-right">{monthA} Spend (R)</th>
                    <th className="py-2 px-3 text-right">{monthB} Spend (R)</th>
                    <th className="py-2 px-3 text-right">Variance (R)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {comparison.categoryComparison.map((cat, idx) => (
                    <tr key={idx}>
                      <td className="py-2 px-3 font-semibold text-slate-800">{cat.category}</td>
                      <td className="py-2 px-3 text-right font-mono">R {cat.monthA.toFixed(2)}</td>
                      <td className="py-2 px-3 text-right font-mono text-slate-500">R {cat.monthB.toFixed(2)}</td>
                      <td className="py-2 px-3 text-right font-mono font-bold">
                        {cat.diff < 0 ? (
                          <span className="text-emerald-700">- R {Math.abs(cat.diff).toFixed(2)} (Saved)</span>
                        ) : cat.diff > 0 ? (
                          <span className="text-rose-700">+ R {cat.diff.toFixed(2)}</span>
                        ) : (
                          <span className="text-slate-400">R 0.00</span>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Alphabetical Item Table */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-3">
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600">
                  Item-by-Item Calculated Ledger (Alphabetical Order A-Z)
                </h4>
                <span className="text-[11px] text-slate-500">
                  Total {comparison.items.length} unique items
                </span>
              </div>

              <table className="w-full text-left text-xs border border-slate-300">
                <thead className="bg-slate-200 text-slate-800 font-bold border-b border-slate-300">
                  <tr>
                    <th className="py-2.5 px-3">Item Description (A-Z)</th>
                    <th className="py-2.5 px-2">Category</th>
                    <th className="py-2.5 px-2 text-center">{monthA} Qty</th>
                    <th className="py-2.5 px-3 text-right">{monthA} Total</th>
                    <th className="py-2.5 px-2 text-center">{monthB} Qty</th>
                    <th className="py-2.5 px-3 text-right">{monthB} Total</th>
                    <th className="py-2.5 px-3 text-right">Variance</th>
                    <th className="py-2.5 px-2 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {comparison.items.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-8 text-center text-slate-400 italic">
                        No itemized records found for {monthA} or {monthB}.
                      </td>
                    </tr>
                  ) : (
                    comparison.items.map((item, idx) => (
                      <tr key={idx} className="border-b border-slate-100">
                        <td className="py-2 px-3 font-semibold text-slate-900">{item.name}</td>
                        <td className="py-2 px-2 text-[10px] text-slate-500">{item.category}</td>
                        <td className="py-2 px-2 text-center font-mono">{item.monthA_quantity}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold">R {item.monthA_total.toFixed(2)}</td>
                        <td className="py-2 px-2 text-center font-mono text-slate-500">{item.monthB_quantity}</td>
                        <td className="py-2 px-3 text-right font-mono text-slate-500">R {item.monthB_total.toFixed(2)}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold">
                          {item.amount_diff < 0 ? (
                            <span className="text-emerald-700">- R {Math.abs(item.amount_diff).toFixed(2)}</span>
                          ) : item.amount_diff > 0 ? (
                            <span className="text-rose-700">+ R {item.amount_diff.toFixed(2)}</span>
                          ) : (
                            <span className="text-slate-400">R 0.00</span>
                          )}
                        </td>
                        <td className="py-2 px-2 text-center text-[10px] font-bold">
                          {item.status === 'saved_more' && <span className="text-emerald-700">Saved More</span>}
                          {item.status === 'not_purchased' && <span className="text-emerald-700">Not Bought</span>}
                          {item.status === 'spent_more' && <span className="text-rose-700">Spent More</span>}
                          {item.status === 'new_item' && <span className="text-blue-700">New Item</span>}
                          {item.status === 'unchanged' && <span className="text-slate-500">Equal</span>}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
                <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-300">
                  <tr>
                    <td colSpan={3} className="py-2.5 px-3">Totals:</td>
                    <td className="py-2.5 px-3 text-right font-mono font-black text-emerald-800">
                      R {comparison.totalA.toFixed(2)}
                    </td>
                    <td></td>
                    <td className="py-2.5 px-3 text-right font-mono text-slate-700">
                      R {comparison.totalB.toFixed(2)}
                    </td>
                    <td className="py-2.5 px-3 text-right font-mono font-black">
                      {isNetSaving ? (
                        <span className="text-emerald-800">- R {Math.abs(comparison.totalDiff).toFixed(2)}</span>
                      ) : (
                        <span className="text-rose-800">+ R {comparison.totalDiff.toFixed(2)}</span>
                      )}
                    </td>
                    <td className="py-2.5 px-2 text-center text-[10px]">
                      {isNetSaving ? 'Saved' : 'Increased'}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </>
        ) : (
          /* Single Month Ledger View */
          <>
            {/* Document Header */}
            <div className="border-b-2 border-slate-900 pb-6 mb-6 flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-2xl font-black tracking-tight text-slate-900">
                    MONTHLY HOUSEHOLD EXPENDITURE LEDGER
                  </span>
                </div>
                <p className="text-xs text-slate-500 font-medium">
                  Detailed Ledger for Month: <strong className="text-slate-800">{monthA}</strong>
                </p>
              </div>

              <div className="text-right">
                <div className="text-xs font-bold text-slate-800 uppercase">Generated On</div>
                <div className="text-xs text-slate-500">{new Date().toLocaleDateString('en-ZA')}</div>
                <div className="text-[10px] text-emerald-700 font-bold mt-1">Currency: ZAR (R)</div>
              </div>
            </div>

            {/* Summary Cards */}
            <div className="grid grid-cols-3 gap-4 mb-6 print-page-break">
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <div className="text-[10px] uppercase font-bold text-slate-400">
                  Total Month Spend
                </div>
                <div className="text-2xl font-black text-slate-900 mt-0.5">
                  R {singleMonthReport.total_spend.toFixed(2)}
                </div>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <div className="text-[10px] uppercase font-bold text-slate-400">
                  Filed Receipts
                </div>
                <div className="text-2xl font-black text-slate-900 mt-0.5">
                  {singleMonthReport.receipt_count} Receipts
                </div>
              </div>

              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl">
                <div className="text-[10px] uppercase font-bold text-slate-400">
                  Unique Line Items
                </div>
                <div className="text-2xl font-black text-slate-900 mt-0.5">
                  {singleMonthReport.item_count} Items
                </div>
              </div>
            </div>

            {/* Category Breakdown */}
            <div className="mb-8 print-page-break">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-3">
                Category Breakdown
              </h4>
              <table className="w-full text-left text-xs border border-slate-200">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2 px-3">Category</th>
                    <th className="py-2 px-3 text-right">Total Spend (R)</th>
                    <th className="py-2 px-3 text-right">% of Total</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {Object.entries(singleMonthReport.category_totals).map(([cat, amt]) => {
                    const pct = singleMonthReport.total_spend > 0 
                      ? ((amt / singleMonthReport.total_spend) * 100).toFixed(1) 
                      : '0.0';
                    return (
                      <tr key={cat}>
                        <td className="py-2 px-3 font-semibold text-slate-800">{cat}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold">R {amt.toFixed(2)}</td>
                        <td className="py-2 px-3 text-right font-mono text-slate-500">{pct}%</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            {/* Recorded Receipts Table */}
            <div className="mb-8 print-page-break">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-3">
                Recorded Receipts ({singleMonthReceipts.length})
              </h4>
              <table className="w-full text-left text-xs border border-slate-200">
                <thead className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                  <tr>
                    <th className="py-2 px-3">Date</th>
                    <th className="py-2 px-3">Store / Vendor</th>
                    <th className="py-2 px-3">Category</th>
                    <th className="py-2 px-3">Tax / Notes</th>
                    <th className="py-2 px-3 text-right">Amount (R)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {singleMonthReceipts.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-4 text-center text-slate-400 italic">No receipts recorded for {monthA}</td>
                    </tr>
                  ) : (
                    singleMonthReceipts.map((r) => (
                      <tr key={r.id}>
                        <td className="py-2 px-3 font-mono">{r.invoice_date}</td>
                        <td className="py-2 px-3 font-semibold text-slate-800">{r.vendor_name}</td>
                        <td className="py-2 px-3 text-slate-600">{r.category}</td>
                        <td className="py-2 px-3 text-slate-500">{r.tax ? `VAT: R ${Number(r.tax).toFixed(2)}` : (r.notes || '-')}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold">R {Number(r.total_amount).toFixed(2)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Itemized Goods Ledger */}
            <div className="mb-6">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 mb-3">
                Itemized Grocery & Goods Ledger (A-Z)
              </h4>
              <table className="w-full text-left text-xs border border-slate-300">
                <thead className="bg-slate-200 text-slate-800 font-bold border-b border-slate-300">
                  <tr>
                    <th className="py-2.5 px-3">Item Description (A-Z)</th>
                    <th className="py-2.5 px-2">Category</th>
                    <th className="py-2.5 px-2 text-center">Total Qty</th>
                    <th className="py-2.5 px-3 text-right">Avg Unit Price</th>
                    <th className="py-2.5 px-3 text-right">Total Spend</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {singleMonthReport.items_alphabetical.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-6 text-center text-slate-400 italic">No items recorded for {monthA}</td>
                    </tr>
                  ) : (
                    singleMonthReport.items_alphabetical.map((item, idx) => (
                      <tr key={idx} className="border-b border-slate-100">
                        <td className="py-2 px-3 font-semibold text-slate-900">{item.name}</td>
                        <td className="py-2 px-2 text-[10px] text-slate-500">{item.categories.join(', ')}</td>
                        <td className="py-2 px-2 text-center font-mono">{item.total_quantity}</td>
                        <td className="py-2 px-3 text-right font-mono text-slate-600">R {item.average_unit_price.toFixed(2)}</td>
                        <td className="py-2 px-3 text-right font-mono font-bold text-slate-900">R {item.total_amount.toFixed(2)}</td>
                      </tr>
                    ))
                  )}
                </tbody>
                <tfoot className="bg-slate-100 font-bold border-t-2 border-slate-300">
                  <tr>
                    <td colSpan={4} className="py-2.5 px-3">Grand Total:</td>
                    <td className="py-2.5 px-3 text-right font-mono font-black text-emerald-800">
                      R {singleMonthReport.total_spend.toFixed(2)}
                    </td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </>
        )}

        {/* Document Footer */}
        <div className="pt-6 border-t border-slate-200 flex items-center justify-between text-[11px] text-slate-400">
          <span>ParserPro Expenditure & Household Tracking</span>
          <span>Confidential Personal Finance Report</span>
        </div>
      </div>
    </div>
  );
};
